Pokemon Arena
=============

##### A text-based Pokemon battle game!

![Pokemon Arena](http://25.media.tumblr.com/tumblr_m9a6eqNYze1qfqgb9o1_500.gif)

Building & Running
------------------

```shell
$ cd lib
$ java PokemonArena
```
